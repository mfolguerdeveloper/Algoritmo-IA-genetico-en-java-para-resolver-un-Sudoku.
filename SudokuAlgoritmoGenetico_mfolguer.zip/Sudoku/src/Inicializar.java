import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
/**
 * Clase que sirve para inicializar el sudoku con leyendo los parametros de los archivos de configuracion y el tablero del sudoku
 * @author Marcos Folguera Rivera
 *
 */
public class Inicializar {

	public Casilla[][] tablero = new Casilla[9][9];
	public ParametrosGeneticos parametros;

	public Inicializar() {
		tablero=new Casilla[9][9];
	}
/**
 * Metodo para comprobar si el fichero existe
 * @param n
 * @return
 */
	protected boolean comprobarFichero(String n) {
		File file = new File(n);
		if (!file.exists()) {
			return false;
		}
		return true;
	}

/**
 * Metodo que lee el fichero donde se encuentra el tablero y crea una matriz de casillas con esos datos
 * @param nombrefi
 * @return
 */
	public Casilla[][] iniciarTablero(String nombrefi) {
		File archivo = null;
		FileReader fr = null;
		BufferedReader br = null;

		try {

			archivo = new File (nombrefi);
			fr = new FileReader (archivo);
			br = new BufferedReader(fr);

			String linea;
			int fil=0;
			int col=0;
			while((linea=br.readLine())!=null) {
				col=0;
				String[] parts = linea.split(",");
				Casilla c;
				for (int i = 0; i < parts.length; i++){

					if(Integer.parseInt(parts[i])!=0) {
						c =new Casilla(Integer.parseInt(parts[i]),true);
						tablero[fil][col]=c;
					}
					else {
						c =new Casilla(Integer.parseInt(parts[i]),false);
						tablero[fil][col]=c;
					}

					col++;
				}
				fil++;
			}
		}
		catch(Exception e){

			e.printStackTrace();
		}finally {
			try {
				fr.close();
			} catch (IOException e) {

				e.printStackTrace();
			} 
		}

		return tablero;
	} 
/**
 * Metodo usado para leer los parametros del fichero de configuracion y guardarlo en un objeto tipo ParametrosGeneticos
 * @param nombrefil
 * @return
 */
	public ParametrosGeneticos leerParametrosGeneticos(String nombrefil) {
		File archivo = null;
		FileReader fr = null;
		BufferedReader br = null;

		try {

			archivo = new File (nombrefil);
			fr = new FileReader (archivo);
			br = new BufferedReader(fr);

			String linea;
			float n1 = 0.0F;
			float n2 =0.0F;
			float n3 = 0.0F;
			float n4 = 0.0F;
			float n5 =0.0F;
			float n6 = 0.0F;
			float n7 = 0.0F;
			float n8 =0.0F;
			float n9 = 0.0F;
			
			String aux="";

				//if(linea.contains("")) {
				linea=br.readLine();
				for (int n = 16; n <linea.length(); n++) {
					aux=aux+linea.charAt(n);	
					n1=Float.parseFloat(aux);
				}
				aux="";
				linea=br.readLine();
				for (int n = 12; n <linea.length(); n++) {
					aux=aux+linea.charAt(n);	
					n2=Float.parseFloat(aux);
				}
				aux="";
				linea=br.readLine();
				for (int n = 22; n <linea.length(); n++) {
					aux=aux+linea.charAt(n);	
					n3=Float.parseFloat(aux);
				}
				aux="";
				linea=br.readLine();
				for (int n = 21; n <linea.length(); n++) {
					aux=aux+linea.charAt(n);	
					n4=Float.parseFloat(aux);
				}
				aux="";
				linea=br.readLine();
				for (int n = 8; n <linea.length(); n++) {
					aux=aux+linea.charAt(n);	
					n5=Float.parseFloat(aux);
				}
				aux="";
				linea=br.readLine();
				for (int n = 21; n <linea.length(); n++) {
					aux=aux+linea.charAt(n);	
					n6=Float.parseFloat(aux);
				}
				aux="";
				linea=br.readLine();
				for (int n = 19; n <linea.length(); n++) {
					aux=aux+linea.charAt(n);	
					n7=Float.parseFloat(aux);
				}
				aux="";
				linea=br.readLine();
				for (int n = 18; n <linea.length(); n++) {
					aux=aux+linea.charAt(n);	
					n8=Float.parseFloat(aux);
				}
				aux="";
				linea=br.readLine();
				for (int n = 20; n <linea.length(); n++) {
					aux=aux+linea.charAt(n);	
					n9=Float.parseFloat(aux);
				}
			
				parametros=new ParametrosGeneticos(n1,n2,n3,n4,n5,n6,n7,n8,n9);
		}
		catch(Exception e){
			e.printStackTrace();
		}finally {
			try {
				fr.close();
			} catch (IOException e) {

				e.printStackTrace();
			} 
		}
System.out.println(parametros.toString());
		return parametros;

	}
	/**
	 * Metodo que muestra la matriz con el tablero de forma grafica
	 * @param tablero
	 */
	public void mostrarSudoku(Casilla[][] tablero) {
		System.out.println("----------------------------------------------------------------------------------");
		for (int x=0; x < tablero.length; x++) {
			System.out.print("|");
			
			for (int y=0; y < tablero[x].length; y++) {
				if((x==3||x==6)&&y==0) {
					System.out.print("--------------------------------------------------------------------------------|");
					System.out.println();
					System.out.print("|");
				}
				
				System.out.print (tablero[x][y].getNumero());

				if (y!=tablero[x].length-1) {	
					
					if((y==2||y==5)) {
						System.out.print("\t");

						System.out.print("|");
					}
					System.out.print("\t");
				}

			}
			System.out.println("|");
		}
		System.out.println("----------------------------------------------------------------------------------");

	}
	
}
