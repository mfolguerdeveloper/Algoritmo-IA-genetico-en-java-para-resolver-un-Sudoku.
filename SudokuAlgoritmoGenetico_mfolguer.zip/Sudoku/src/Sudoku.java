import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;



/**
 * Clase que ejecuta el algoritmo genetico y da las directrices para su funcionamiento a traves de las clases restantes
 * @author Marcos Folguera Rivera
 *
 */
public class Sudoku {


	/**
	 * Metodo principal que ejecuta todo el algoritmo
	 * @param args
	 */
	public static void main(String[] args) {


		ParametrosGeneticos parametros;
		Inicializar sudoku=new Inicializar();
		FileWriter fichero = null;
		PrintWriter pw = null;
		File New_File = new File("./bitácora.txt");

		try {
			if (New_File.createNewFile()){
			}
			else{
				BufferedWriter bw = new BufferedWriter(new FileWriter("./bitácora.txt"));
				bw.write("");
				bw.close();


			}
		} catch (IOException e1) {
			e1.printStackTrace();
		}
		FileWriter fw = null;
		try {
			fw = new FileWriter("./bitácora.txt", true);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		BufferedWriter bw = new BufferedWriter(fw);
		PrintWriter out = new PrintWriter(bw);



		parametros=sudoku.leerParametrosGeneticos("Config.txt");

		int ELITISM_K = Math.round(parametros.getElitism());
		int POP_SIZE =  Math.round(parametros.getPopulation_Size())+ELITISM_K;
		int MAX_ITER = Math.round(parametros.getGenerations());
		double MUTATION_RATE = parametros.getMutation_Probability();
		double CROSSOVER_RATE =parametros.getCrossover_Probability();


		Population pop = new Population(ELITISM_K, POP_SIZE, MAX_ITER,
				MUTATION_RATE, CROSSOVER_RATE);
		pop.evaluate();

//Se crea la poblacion con todos los individuos
		Individual[] newPop = new Individual[POP_SIZE];
		Individual[] indiv = new Individual[2];

		// current population
		System.out.println("Iteration: 0");
		System.out.print("Total Fitness = " + pop.gettotalFirness());
		System.out.println(" ; Best Fitness = "
				+ pop.findBestIndividual().getFitnessValue());
		System.out.println("Best Individual: ");


		pop.findBestIndividual().show_Individual();

		int count;
		boolean solucion=false;
		Casilla[][] tableroSol = null ;

		if(pop.findBestIndividual().getFitnessValue()==0) {
			solucion=true;
			tableroSol=pop.findBestIndividual().getGenes();
		}

		for (int iter = 0; iter <= MAX_ITER&&!solucion; iter++) {
			count = 0;

			// Se definen los individuos Elististas
			for (int i = 0; i < ELITISM_K; ++i) {
				newPop[count] = pop.findBestIndividual();

				if(newPop[count].getFitnessValue()==0){
					tableroSol=newPop[count].getGenes();
					solucion=true;
				}
				count++;
			}

			// build new Population
			while (count < POP_SIZE&&!solucion) {
				// Selection
				if(parametros.getSelection_Algorithm()==0) {
					indiv[0] = pop.rouletteWheelSelection();
					indiv[1] = pop.rouletteWheelSelection();
				}
				if(parametros.getSelection_Algorithm()==1) {
					indiv[0] = pop.rankSelection();
					indiv[1] = pop.rankSelection();
				}
				if(parametros.getSelection_Algorithm()==2) {
					indiv[0] = pop.tournamentSelection();
					indiv[1] = pop.tournamentSelection();
				}
				if(parametros.getSelection_Algorithm()==3) {
					indiv[0] = pop.truncatedSelection();
					indiv[1] = pop.truncatedSelection();
				}
				Individual[] familia = new Individual[4];
				familia[0]=indiv[0];
				familia[1]=indiv[1];
				// Aqui se hacen los 3 tipos de Crossover Cruce de indivuduos que exige la practica (En un punto, Multipunto y Uniforme)
				if (pop.getm_rand() < CROSSOVER_RATE) {
					if(parametros.getCrossover_Operator()==0) {
						indiv = pop.crossover0EnUnPunto(indiv[0], indiv[1]);
					}else if(parametros.getCrossover_Operator()==1) {
						indiv = pop.crossover1Multipunto(indiv[0], indiv[1]);
					}else if(parametros.getCrossover_Operator()==2) {
						indiv = pop.crossover2Uniforme(indiv[0], indiv[1]);
					}

				}
				familia[2]=indiv[0];
				familia[3]=indiv[1];
				// Aqui se hacen los 2 tipos de Mutacion Cruce de indivuduos que exige la practica (orientada y aleatoria)
				if (pop.getm_rand() < MUTATION_RATE) {
					indiv[0].mutate((int) parametros.getMutation_Operator());
				}
				if (pop.getm_rand() < MUTATION_RATE) {
					indiv[1].mutate((int) parametros.getMutation_Operator());
				}

				// Se añaden los nuevos elementos a la poblacion dependiendo de la Estrategia de Remplazamiento utilizada 
				
				//Replacement Strategy=0 Estacionario
				if(parametros.getReplacement_Strategy()==0) {
					newPop[count] = indiv[0];

					if(newPop[count].getFitnessValue()==0){
						tableroSol=newPop[count].getGenes();
						solucion=true;
					}
					newPop[count + 1] = indiv[1];

					if(newPop[count+1].getFitnessValue()==0){
						tableroSol=newPop[count+1].getGenes();
						solucion=true;
					}
				}
				//Replacement Strategy=1 Generacional
				if(parametros.getReplacement_Strategy()==1) {

					for (int x = 0; x < familia.length; x++) {
						for (int i = 0; i < familia.length-x-1; i++) {
							if(familia[i].getFitnessValue() > familia[i+1].getFitnessValue()){
								int tmp = familia[i+1].getFitnessValue();
								familia[i+1].setFitnessValue(familia[i].getFitnessValue());
								familia[i].setFitnessValue(tmp); 
							}
						}
					}

					newPop[count] = familia[0];

					if(newPop[count].getFitnessValue()==0){
						tableroSol=newPop[count].getGenes();
						solucion=true;
					}
					newPop[count + 1] = familia[1];

					if(newPop[count+1].getFitnessValue()==0){
						tableroSol=newPop[count+1].getGenes();
						solucion=true;
					}
				}

				count += 2;
			}
			pop.setPopulation(newPop);

			// Se vuelve a evaluar la poblacion
			pop.evaluate();
			Individual sol = new Individual();
			sol=pop.findBestIndividual();
			System.out.println("Iteration: "+ iter);
			System.out.print("Total Fitness = " + pop.gettotalFirness());
			System.out.println(" ; Best Fitness = "
					+ sol.getFitnessValue());
			System.out.println("Best Individual: ");
			sol.show_Individual();
			out.println(pop.gettotalFirness()+"-"+sol.getFitnessValue());

			//Se comprueba si existe la solucion
			if(sol.getFitnessValue()==0) {
				solucion=true;
				tableroSol=sol.getGenes();
			}

		}
		if(solucion) {
			System.out.println("------------------------------------------------------------------");
			System.out.println("				Se ha encontrado la solucion  ");
			System.out.println("------------------------------------------------------------------");
			sudoku.mostrarSudoku(tableroSol);
		}
	
		try {
			bw.close();
		} catch (IOException e) {
			
			e.printStackTrace();
		}
		out.close();

		//Se establece el mejor individuo y se muestra por pantalla
		Individual bestIndiv = pop.findBestIndividual();
		System.out.println("Best Final Individual: ");
		pop.findBestIndividual().show_Individual();

	}


}
