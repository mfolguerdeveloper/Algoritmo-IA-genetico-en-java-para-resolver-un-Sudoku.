

import java.util.Random;
/**
 * Clase utilizada para representar a un individuo como un sudoku y su fitnes que es el valor del individuo
 * Contiene los metodos para evaluar a cada individuo(fitnees) y para mutarlo aleatoriamente y de manera orientada
 * 
 *
 */
public class Individual {
	public static final int SIZE = 81;
	Casilla[][] genes;
	private int fitnessValue;
	Inicializar sudoku=new Inicializar();


	public Individual() {


		if(!sudoku.comprobarFichero("sudoku.txt")) {
			System.out.println("El fichero con el sudoku no existe");
		}else {
			genes=sudoku.iniciarTablero("sudoku.txt");
			fitnessValue=0;
		}


	}
	public Individual(Casilla[][] genes) {
		this.genes=genes;
		this.fitnessValue=0;
	}
	public int getFitnessValue() {
		return fitnessValue;
	}

	public void setFitnessValue(int fitnessValue) {
		this.fitnessValue = fitnessValue;
	}

	public Casilla getGene(int fil,int col) {
		return genes[fil][col];
	}

	public Casilla[][] getGenes() {
		return genes;
	}

	public void setGenes(Casilla[][] tablero) {
		genes=tablero;
	}

	public void setGene(int fil,int col,int num) {
		this.genes[fil][col].setNumero(num);
	}
	/**
	 * Metodo para inicializar los individuos con numeros aleatorios
	 */
	public void randGenes() {
		Random rand = new Random();

		for (int x=0; x < genes.length; x++) {

			for (int y=0; y < genes[x].length; y++) {

				if(!genes[x][y].isFija()) {

					this.setGene(x,y,(rand.nextInt(9)+1));
				}
			}
		}

	}

	/**
	 * Metodo para mutar a un individuo (cambia el valor de las casilla no fijas)
	 * @param num Si num=0 la mutacion sera aleatoria(cambiar por numeros randoms), Si num=1 la mutacion sera orientada(BUscamos los numeros que encajen y los ponemos)
	 */
	public void mutate(int num) {
		Random rand = new Random();

		if(num==0) {
			//mutacion aleatoria
			int fil=rand.nextInt(8);
			int col=rand.nextInt(8);
			while(genes[fil][col].isFija()) {
				fil=rand.nextInt(8);
				col=rand.nextInt(8);
			}
			int numAux=rand.nextInt(8);
			this.setGene(fil,col, numAux);
		}else if(num==1) {

			if(fitnessValue<20) {

			}
			//mutacion guide
			for (int i = 0; i < 81; i++){
				int fil=rand.nextInt(8);
				//false para filas
				mutateOrientative(fil,false);
				//true para colum
				mutateOrientative(fil,true);
				mutateOrientativeMiniMatrices(fil);
			}

		}
	}
	/**
	 * Mutacion de obtiene una numero=fil y un eje=columnas o filas y cambia un numero que se repita por uno que falte
	 * @param fil
	 * @param eje
	 */
	public void mutateOrientative(int fil,boolean eje) {
		int col=0;
		boolean fact=true;


		int vector[] =  {0,0,0,0,0,0,0,0,0};

		for (col = 0; col < genes.length&&fact; col++){
			if(eje) {
				int aux=fil;
				fil=col;
				col=aux;
			}

			switch (genes[fil][col].getNumero()) { 
			case 1:
				vector[0]++;
				break;
			case 2:
				vector[1]++;
				break;
			case 3 :
				vector[2]++;
				break;
			case 4 :
				vector[3]++;
				break;
			case 5 :
				vector[4]++;
				break;
			case 6 :
				vector[5]++;
				break;
			case 7 :
				vector[6]++;
				break;
			case 8 :
				vector[7]++;
				break;
			case 9 :
				vector[8]++;
				break;
			default:
			}
			if(eje) {
				int aux=fil;
				fil=col;
				col=aux;
			}

		}
		int mayor=-1;
		int numeroRepe=-1;
		for(int i=0; i < vector.length&&fact; i++){
			if(vector[i]>=mayor) {
				mayor=vector[i];
				numeroRepe=i+1;
			}
		}


		boolean SegundaVez=true;
		for (col = 0; col < genes.length&&fact; col++){
			if(eje) {
				int aux=fil;
				fil=col;
				col=aux;
			}
			if(genes[fil][col].getNumero()==numeroRepe) { 

				if(SegundaVez) {
					for(int i=0; i < vector.length&&fact; i++){
						if(vector[i]==0) {
							if(!genes[fil][col].isFija()) {
								this.setGene(fil,col, i+1);
								fact=false;
							}


						}
					}
				}
				SegundaVez=true;
			}
			if(eje) {
				int aux=fil;
				fil=col;
				col=aux;
			}
		}


	}
	/**
	 * Metodo usado en mutateOrientative para contar las veces que se repite un numero=num en el vector=vector
	 * @param vector
	 * @param num
	 * @return
	 */
	public int[] contarFallos(int[] vector ,int num ) {
		switch (num) { 
		case 1:
			vector[0]++;
			break;
		case 2:
			vector[1]++;
			break;
		case 3 :
			vector[2]++;
			break;
		case 4 :
			vector[3]++;
			break;
		case 5 :
			vector[4]++;
			break;
		case 6 :
			vector[5]++;
			break;
		case 7 :
			vector[6]++;
			break;
		case 8 :
			vector[7]++;
			break;
		case 9 :
			vector[8]++;
			break;
		default:
		}
		return vector;
	}
	/**
	 * Metodo que busca en una minimatriz del sudoku(3x3)=cuadrante un numero que se repita y lo cambia por uno que falte
	 * @param cuadrante
	 */
	public void mutateOrientativeMiniMatrices(int cuadrante) {
		int col=0;
		int fil=0;
		boolean fact=true;


		int vector[] =  {0,0,0,0,0,0,0,0,0};


		switch (cuadrante) { 
		case 1:	

			for (fil = 0; fil < 3; fil++){
				for (col = 0; col < 3; col++){
					vector=contarFallos(vector,genes[fil][col].getNumero());
				}
			}

			break;
		case 2:
			for (fil = 0; fil < 3; fil++){
				for (col = 3; col < 6; col++){
					vector=contarFallos(vector,genes[fil][col].getNumero());
				}
			}
			break;
		case 3 :
			for (fil = 0; fil < 3; fil++){
				for (col = 6; col < 9; col++){
					vector=contarFallos(vector,genes[fil][col].getNumero());
				}
			}	
			break;
		case 4 :
			for (fil = 3; fil < 6; fil++){
				for (col = 0; col < 3; col++){
					vector=contarFallos(vector,genes[fil][col].getNumero());
				}
			}
			break;
		case 5 :
			for (fil = 3; fil < 6; fil++){
				for (col = 3; col < 6; col++){
					vector=contarFallos(vector,genes[fil][col].getNumero());
				}
			}		
			break;
		case 6 :
			for (fil = 3; fil < 6; fil++){
				for (col = 6; col < 9; col++){
					vector=contarFallos(vector,genes[fil][col].getNumero());
				}
			}						
			break;
		case 7 :
			for (fil = 6; fil < 9; fil++){
				for (col = 0; col < 3; col++){
					vector=contarFallos(vector,genes[fil][col].getNumero());
				}
			}		
			break;
		case 8 :
			for (fil = 6; fil < 9; fil++){
				for (col = 3; col < 6; col++){
					vector=contarFallos(vector,genes[fil][col].getNumero());
				}
			}			
			break;
		case 9 :
			for (fil = 6; fil < 9; fil++){
				for (col = 6; col < 9; col++){
					vector=contarFallos(vector,genes[fil][col].getNumero());
				}
			}			
			break;
		default:
		}






		int mayor=-1;
		int numeroRepe=-1;
		for(int i=0; i < vector.length&&fact; i++){
			if(vector[i]>=mayor) {
				mayor=vector[i];
				numeroRepe=i+1;
			}
		}

		boolean SegundaVez=true;

		switch (cuadrante) { 
		case 1:	

			for (fil = 0; fil < 3&&fact; fil++){
				for (col = 0; col < 3&&fact; col++){
					if(genes[fil][col].getNumero()==numeroRepe) { 

						if(SegundaVez) {
							for(int i=0; i < vector.length&&fact; i++){
								if(vector[i]==0) {
									if(!genes[fil][col].isFija()) {

										this.setGene(fil,col, i+1);
										fact=false;
									}
								}
							}
						}
						SegundaVez=true;
					}				}
			}

			break;
		case 2:
			for (fil = 0; fil < 3&&fact; fil++){
				for (col = 3; col < 6&&fact; col++){
					if(genes[fil][col].getNumero()==numeroRepe) { 

						if(SegundaVez) {
							for(int i=0; i < vector.length&&fact; i++){
								if(vector[i]==0) {
									if(!genes[fil][col].isFija()) {

										this.setGene(fil,col, i+1);
										fact=false;
									}
								}
							}
						}
						SegundaVez=true;
					}				}
			}
			break;
		case 3 :
			for (fil = 0; fil < 3&&fact; fil++){
				for (col = 6; col < 9&&fact; col++){
					if(genes[fil][col].getNumero()==numeroRepe) { 

						if(SegundaVez) {
							for(int i=0; i < vector.length&&fact; i++){
								if(vector[i]==0) {
									if(!genes[fil][col].isFija()) {

										this.setGene(fil,col, i+1);
										fact=false;
									}
								}
							}
						}
						SegundaVez=true;
					}				}
			}	
			break;
		case 4 :
			for (fil = 3; fil < 6&&fact; fil++){
				for (col = 0; col < 3&&fact; col++){
					if(genes[fil][col].getNumero()==numeroRepe) { 

						if(SegundaVez) {
							for(int i=0; i < vector.length&&fact; i++){
								if(vector[i]==0) {
									if(!genes[fil][col].isFija()) {

										this.setGene(fil,col, i+1);
										fact=false;
									}
								}
							}
						}
						SegundaVez=true;
					}				}
			}
			break;
		case 5 :
			for (fil = 3; fil < 6&&fact; fil++){
				for (col = 3; col < 6&&fact; col++){
					if(genes[fil][col].getNumero()==numeroRepe) { 

						if(SegundaVez) {
							for(int i=0; i < vector.length&&fact; i++){
								if(vector[i]==0) {
									if(!genes[fil][col].isFija()) {

										this.setGene(fil,col, i+1);
										fact=false;
									}
								}
							}
						}
						SegundaVez=true;
					}				}
			}		
			break;
		case 6 :
			for (fil = 3; fil < 6&&fact; fil++){
				for (col = 6; col < 9&&fact; col++){
					if(genes[fil][col].getNumero()==numeroRepe) { 

						if(SegundaVez) {
							for(int i=0; i < vector.length&&fact; i++){
								if(vector[i]==0) {
									if(!genes[fil][col].isFija()) {

										this.setGene(fil,col, i+1);
										fact=false;
									}
								}
							}
						}
						SegundaVez=true;
					}				}
			}						
			break;
		case 7 :
			for (fil = 6; fil < 9&&fact; fil++){
				for (col = 0; col < 3&&fact; col++){
					if(genes[fil][col].getNumero()==numeroRepe) { 

						if(SegundaVez) {
							for(int i=0; i < vector.length&&fact; i++){
								if(vector[i]==0) {
									if(!genes[fil][col].isFija()) {

										this.setGene(fil,col, i+1);
										fact=false;
									}
								}
							}
						}
						SegundaVez=true;
					}				}
			}		
			break;
		case 8 :
			for (fil = 6; fil < 9&&fact; fil++){
				for (col = 3; col < 6&&fact; col++){
					if(genes[fil][col].getNumero()==numeroRepe) { 

						if(SegundaVez) {
							for(int i=0; i < vector.length&&fact; i++){
								if(vector[i]==0) {
									if(!genes[fil][col].isFija()) {

										this.setGene(fil,col, i+1);
										fact=false;
									}
								}
							}
						}
						SegundaVez=true;
					}				}
			}			
			break;
		case 9 :
			for (fil = 6; fil < 9&&fact; fil++){
				for (col = 6; col < 9&&fact; col++){

					if(genes[fil][col].getNumero()==numeroRepe) { 

						if(SegundaVez) {
							for(int i=0; i < vector.length&&fact; i++){
								if(vector[i]==0) {
									if(!genes[fil][col].isFija()) {

										this.setGene(fil,col, i+1);
										fact=false;
									}
								}
							}
						}
						SegundaVez=true;
					}				}
			}			
			break;
		default:
		}



	}


	/**
	 * Metodo que cuenta el numero de veces que se repite cada numero en cada fila columna y minimatriz del tablero
	 * @return
	 */
	public  int evaluate() {
		int fil=0;
		int col=0;
		int contadorFallos=0;
		for (fil = 0; fil < genes.length; fil++){

			for (col = 0; col < genes.length; col++){

				contadorFallos=comprobarEjes(genes,genes[fil][col].getNumero(),fil,col)+contadorFallos;

				contadorFallos=comprobarCuadrante(genes,genes[fil][col].getNumero(),fil,col)+contadorFallos;


			}
		}
		this.setFitnessValue(contadorFallos);

		return contadorFallos;
	}
	/**
	 * Metodo que cuenta las veces que se repiten los numeros en cada una de las filas y columnas del tablero
	 * @param tablero
	 * @param num
	 * @param x
	 * @param y
	 * @return
	 */
	public  int comprobarEjes(Casilla[][] tablero,int num,int x,int y) {
		int contadorFallos=0;
		for (int cont = 0; cont < tablero.length; cont++){
			if(num==tablero[x][cont].getNumero()) {

				if(!(y==cont)) {
					contadorFallos++;
				}


			}
		}
		for (int cont = 0; cont < tablero.length; cont++){
			if(num==tablero[cont][y].getNumero()) {

				if(!(x==cont)) {
					contadorFallos++;
				}


			}
		}
		return contadorFallos;
	}
	/**
	 * Metodo que cuenta las veces que se repiten los numeros en cada una de las minimatrices(3x3) del tablero
	 * @param tablero
	 * @param num
	 * @param x
	 * @param y
	 * @return
	 */
	public  int comprobarCuadrante(Casilla[][] tablero,int num,int x,int y) {

		int fil=0;
		int col=0;
		int contadorFallos=0;
		if(x==0||x==1||x==2) {
			if(y==0||y==1||y==2) {

				for (fil = 0; fil < 3; fil++){
					for (col = 0; col < 3; col++){
						if(num==tablero[fil][col].getNumero()) {
							if(!(x==fil&&y==col)) {
								contadorFallos++;

							}
						}
					}
				}

			}else
				if(y==3||y==4||y==5) {
					for (fil = 0; fil < 3; fil++){
						for (col = 3; col < 6; col++){
							if(num==tablero[fil][col].getNumero()) {
								if(!(x==fil&&y==col)) {
									contadorFallos++;
								}
							}
						}
					}
				}else
					if(y==6||y==7||y==8) {
						for (fil = 0; fil < 3; fil++){
							for (col = 6; col < 9; col++){
								if(num==tablero[fil][col].getNumero()) {
									if(!(x==fil&&y==col)) {
										contadorFallos++;
									}
								}
							}
						}
					}
		}else
			if(x==3||x==4||x==5) {
				if(y==0||y==1||y==2) {
					for (fil = 3; fil < 6; fil++){
						for (col = 0; col < 3; col++){
							if(num==tablero[fil][col].getNumero()) {
								if(!(x==fil&&y==col)) {
									contadorFallos++;
								}
							}
						}
					}
				}else
					if(y==3||y==4||y==5) {
						for (fil = 3; fil < 6; fil++){
							for (col = 3; col < 6; col++){
								if(num==tablero[fil][col].getNumero()) {
									if(!(x==fil&&y==col)) {
										contadorFallos++;
									}
								}
							}
						}
					}else
						if(y==6||y==7||y==8) {
							for (fil = 3; fil < 6; fil++){
								for (col = 6; col < 9; col++){
									if(num==tablero[fil][col].getNumero()) {
										if(!(x==fil&&y==col)) {
											contadorFallos++;
										}
									}
								}
							}
						}
			}else
				if(x==6||x==7||x==8) {
					if(y==0||y==1||y==2) {
						for (fil = 6; fil < 9; fil++){
							for (col = 0; col < 3; col++){
								if(num==tablero[fil][col].getNumero()) {
									if(!(x==fil&&y==col)) {
										contadorFallos++;
									}
								}
							}
						}
					}else
						if(y==3||y==4||y==5) {
							for (fil = 6; fil < 9; fil++){
								for (col = 3; col < 6; col++){
									if(num==tablero[fil][col].getNumero()) {
										if(!(x==fil&&y==col)) {
											contadorFallos++;
										}
									}
								}
							}
						}else
							if(y==6||y==7||y==8) {
								for (fil = 6; fil < 9; fil++){
									for (col = 6; col < 9; col++){
										if(num==tablero[fil][col].getNumero()) {
											if(!(x==fil&&y==col)) {
												contadorFallos++;
											}
										}
									}
								}
							}
				}

		return contadorFallos;

	}
	/**
	 * Metodo que muestra la matriz con el tablero de forma grafica
	 */
	public void show_Individual(){
		for (int x=0; x < genes.length; x++) {
			System.out.print("|");

			for (int y=0; y < genes[x].length; y++) {
				if((x==3||x==6)&&y==0) {
					System.out.print("--------------------------------------------------------------------------------|");
					System.out.println();
					System.out.print("|");
				}

				System.out.print (genes[x][y].getNumero());

				if (y!=genes[x].length-1) {	

					if((y==2||y==5)) {
						System.out.print("\t");

						System.out.print("|");
					}
					System.out.print("\t");
				}

			}
			System.out.println("|");
		}
		System.out.println("----------------------------------------------------------------------------------");

	}

}
