/**
 * Clase utilizada para guardar en un objeto los parametros de configuracion del algoritmo genetico
 * @author Marcos Folguera Rivera
 *
 */
public class ParametrosGeneticos {

	float  Population_Size ;
	float Generations ;
	float Crossover_Probability ;
	float Mutation_Probability ;
	float Elitism ;
	float Replacement_Strategy ;
	float Crossover_Operator ;
	float Mutation_Operator ;
	float Selection_Algorithm ;
	
	
	
	public ParametrosGeneticos() {
		
		Population_Size = 0.0F;
		Generations =  0.0F;
		Crossover_Probability =  0.0F;
		Mutation_Probability =  0.0F;
		Elitism =  0.0F;
		Replacement_Strategy =  0.0F;
		Crossover_Operator =  0.0F;
		Mutation_Operator =  0.0F;
		Selection_Algorithm =  0.0F;
	}
	
	public ParametrosGeneticos(float population_Size, float generations, float crossover_Probability,
			float mutation_Probability, float elitism, float replacement_Strategy, float crossover_Operator,
			float mutation_Operator, float selection_Algorithm) {
		
		Population_Size = population_Size;
		Generations = generations;
		Crossover_Probability = crossover_Probability;
		Mutation_Probability = mutation_Probability;
		Elitism = elitism;
		Replacement_Strategy = replacement_Strategy;
		Crossover_Operator = crossover_Operator;
		Mutation_Operator = mutation_Operator;
		Selection_Algorithm = selection_Algorithm;
	}

	public float getPopulation_Size() {
		return Population_Size;
	}

	public void setPopulation_Size(float population_Size) {
		Population_Size = population_Size;
	}

	public float getGenerations() {
		return Generations;
	}

	public void setGenerations(float generations) {
		Generations = generations;
	}

	public float getCrossover_Probability() {
		return Crossover_Probability;
	}

	public void setCrossover_Probability(float crossover_Probability) {
		Crossover_Probability = crossover_Probability;
	}

	public float getMutation_Probability() {
		return Mutation_Probability;
	}

	public void setMutation_Probability(float mutation_Probability) {
		Mutation_Probability = mutation_Probability;
	}

	public float getElitism() {
		return Elitism;
	}

	public void setElitism(float elitism) {
		Elitism = elitism;
	}

	public float getReplacement_Strategy() {
		return Replacement_Strategy;
	}

	public void setReplacement_Strategy(float replacement_Strategy) {
		Replacement_Strategy = replacement_Strategy;
	}

	public float getCrossover_Operator() {
		return Crossover_Operator;
	}

	public void setCrossover_Operator(float crossover_Operator) {
		Crossover_Operator = crossover_Operator;
	}

	public float getMutation_Operator() {
		return Mutation_Operator;
	}

	public void setMutation_Operator(float mutation_Operator) {
		Mutation_Operator = mutation_Operator;
	}

	public float getSelection_Algorithm() {
		return Selection_Algorithm;
	}

	public void setSelection_Algorithm(float selection_Algorithm) {
		Selection_Algorithm = selection_Algorithm;
	}

	@Override
	public String toString() {
		return "ParametrosGeneticos [Population_Size=" + Population_Size + ", Generations=" + Generations
				+ ", Crossover_Probability=" + Crossover_Probability + ", Mutation_Probability=" + Mutation_Probability
				+ ", Elitism=" + Elitism + ", Replacement_Strategy=" + Replacement_Strategy + ", Crossover_Operator="
				+ Crossover_Operator + ", Mutation_Operator=" + Mutation_Operator + ", Selection_Algorithm="
				+ Selection_Algorithm + "]";
	}
	
}
