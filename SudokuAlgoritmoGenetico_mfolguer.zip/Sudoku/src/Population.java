

import java.util.Arrays;
import java.util.Random;
/**
 * Clase utilizada para guardar los individuos de una generacion y establecer los parametros de la generacion
 * Contiene los metodos de selecion de individuos metodos: ruleta ,rank ,tournament y truncated.
 * Contiene los metodos de cruce de individuos metodos de cruce:en un punto,multipunto,uniforme
 * @author Marcos Folguera Rivera
 *
 */
public class Population {
	int ELITISM_K;
	int POP_SIZE; // population size
	int MAX_ITER; // max number of iterations
	double MUTATION_RATE; // probability of mutation
	double CROSSOVER_RATE; // probability of crossover

	private static Random m_rand = new Random(); // random-number generator
	private Individual[] m_population;
	private double totalFitness;

	/**
	 * Metodo para inicializar la poblacion y establecer sus parametos
	 * @param _ELITISM_K
	 * @param _POP_SIZE
	 * @param _MAX_ITER
	 * @param _MUTATION_RATE
	 * @param _CROSSOVER_RATE
	 */
	public Population(int _ELITISM_K, int _POP_SIZE, int _MAX_ITER,
			double _MUTATION_RATE, double _CROSSOVER_RATE) {
		this.ELITISM_K = _ELITISM_K;
		this.POP_SIZE = _POP_SIZE;
		this.MAX_ITER = _MAX_ITER;
		this.MUTATION_RATE = _MUTATION_RATE;
		this.CROSSOVER_RATE = _CROSSOVER_RATE;

		m_population = new Individual[POP_SIZE];

		// init population
		for (int i = 0; i < POP_SIZE; i++) {
			m_population[i] = new Individual();
			m_population[i].randGenes();
		}

		// Se evalua a la poblacion
		this.evaluate();
	}

	public void setPopulation(Individual[] newPop) {
		System.arraycopy(newPop, 0, this.m_population, 0, POP_SIZE);
	}

	public double gettotalFirness() {
		return this.totalFitness;
	}

	public double getm_rand() {
		return this.m_rand.nextDouble();
	}

	public Individual[] getPopulation() {
		return this.m_population;
	}
	/**
	 * Metodo que ordena los individuos de la poblacion en funcion a suvalor de fitnes de menor a mayor
	 * @param m_population
	 */
	public void ordenar(Individual[] m_population) {

		for (int x = 0; x < m_population.length; x++) {
			for (int i = 0; i < m_population.length-x-1; i++) {
				if(m_population[i].getFitnessValue() > m_population[i+1].getFitnessValue()){
					int tmp = m_population[i+1].getFitnessValue();
					m_population[i+1].setFitnessValue(m_population[i].getFitnessValue());
					m_population[i].setFitnessValue(tmp); 
				}
			}
		}
	}
	/**
	 * Metodo que suma la fitnes de cada infividuo de todala poblacion
	 * @return
	 */
	public double evaluate() {
		this.totalFitness = 0.0;
		for (int i = 0; i < POP_SIZE; i++) {
			this.totalFitness += m_population[i].evaluate();
		}
		return this.totalFitness;

	}

	/**
	 * Metodo de selecion de individuos. Este metodo utiliza la probabilidad de que un individuo sea seleccionado
	 * esproporcional a su fitness relativo
	 * 
	 * @return
	 */
	public Individual rouletteWheelSelection() {
		ordenar(m_population);

		double randNum = m_rand.nextDouble() * this.totalFitness;
		int idx;
		for (idx = 0; idx < POP_SIZE && randNum > 0; ++idx) {
			randNum -= m_population[idx].getFitnessValue();
		}
		return m_population[idx - 1];
	}

	/**
	 * Metodo de selecion de individuos.Este metodo utiliza la probabilidad de selección de un individuo es inversamente
	 * proporcional a la posición que ocupa tras ordenar todos los individuos de mayor a
	 * menor fitness
	 * @return
	 */
	public Individual rankSelection() {
		ordenar(m_population);
		int idx;
		int selector=0;
		double numRand=getm_rand();
		for (idx = 0; idx < POP_SIZE; ++idx) {
			double numAux=idx/m_population.length;

			if ( numRand< numAux ) {
				selector=idx;
			}

		}
		return m_population[selector];
	}

	/**
	 * Metodo de selecion de individuos.Este metodo se basa en las selecciones aleatorias de
	 * individuos, habiendo descartado primero los n individuos con menor fitness de la
	 * población.
	 * @return
	 */
	public Individual truncatedSelection() {
		ordenar(m_population);
		int numAux=(int) (m_population.length*0.3);
		int num = (int)(Math.random()*numAux);
		return m_population[num];
	}

	/**
	 * Metodo de selecion de individuos.Su funcionamiento se basa en la  seleccionan aleatoriamente dos parejas de
	 * individuos de la población (todos con la misma probabilidad). De cada pareja se
	 * selecciona el que tenga mayor fitness. Finalmente, se comparan los dos finalistas y se
	 * selecciona el de mayor fitness.
	 * @return
	 */
	public Individual tournamentSelection() {
		//ordenar(m_population);
		int indi1=0;
		int indi2=0;
		int indi=0;
		int p1a = (int)(Math.random()*m_population.length);
		int p1b = (int)(Math.random()*m_population.length);
		int p2a = (int)(Math.random()*m_population.length);
		int p2b = (int)(Math.random()*m_population.length);
		if(m_population[p1a].getFitnessValue()<=m_population[p1a].getFitnessValue()){
			indi1=p1a;
		}else {
			indi1=p1b;
		}
		if(m_population[p2a].getFitnessValue()<=m_population[p2a].getFitnessValue()){
			indi2=p2a;
		}else {
			indi2=p2b;
		}
		if(m_population[indi1].getFitnessValue()<=m_population[indi2].getFitnessValue()){
			indi=indi1;
		}else {
			indi=indi2;
		}
		return m_population[indi];
	}

	/**
	 * Metodo que busca en toda la poblacion el individuo que menor firnes tenga
	 * @return
	 */
	public  Individual findBestIndividual(){ 
		int cercano = 10000;
		int ind=0;
		for (int i = 0; i < POP_SIZE ; i++){
			if (m_population[i].getFitnessValue() ==  0){
				return m_population[i];
			}else {

				if (cercano > m_population[i].getFitnessValue()){
					cercano =m_population[i].getFitnessValue();
					ind=i;
				}

			}
		}
		return m_population[ind];
	}

	/**
	 * Metodo utilizado para cruzar dos individuos=padres y devuelve en un array los dos individuos resultantes=hijos
	 * Este metodo funciona mediante la selecion de una linea imaginaria que divide a los dos tablero en dos partes los cruza para generar dos individuos nuevos
	 * @param indiv1
	 * @param indiv2
	 * @return
	 */
	public static Individual[] crossover0EnUnPunto(Individual indiv1, Individual indiv2) {
		Individual[] newIndiv = new Individual[2];
		Casilla[][] hijo1 = new Casilla[9][9];
		Casilla[][] hijo2 = new Casilla[9][9];
		Random rand = new Random();
		int fil = (rand.nextInt(7)+1);

		for (int x=0; x < 9; x++) {
			for (int y=0; y < 9; y++) {

				if(x<fil) {
					hijo1[x][y]=new Casilla(indiv2.getGenes()[x][y].getNumero(),indiv2.getGenes()[x][y].isFija());


					hijo2[x][y]=new Casilla(indiv2.getGenes()[x][y].getNumero(),indiv2.getGenes()[x][y].isFija());

				}else {
					hijo1[x][y]=new Casilla(indiv1.getGenes()[x][y].getNumero(),indiv1.getGenes()[x][y].isFija());

					hijo2[x][y]=new Casilla(indiv1.getGenes()[x][y].getNumero(),indiv1.getGenes()[x][y].isFija());

				}
			}

		}
		newIndiv[0]=new Individual(hijo1);
		newIndiv[0].evaluate();
		newIndiv[1]=new Individual(hijo2);
		newIndiv[1].evaluate();
		return newIndiv;
	}
	/**
	 * Metodo utilizado para cruzar dos individuos=padres y devuelve en un array los dos individuos resultantes=hijos
	 * Este metodo funciona mediante la selecion de dos linea imaginaria que divide a los dos tablero en tres partes y los cruza para generar dos individuos nuevos
	 * @param indiv1
	 * @param indiv2
	 * @return
	 */
	public static Individual[] crossover1Multipunto(Individual indiv1, Individual indiv2) {
		Individual[] newIndiv = new Individual[2];
		Casilla[][] hijo1 = new Casilla[9][9];
		Casilla[][] hijo2 = new Casilla[9][9];
		Random rand = new Random();
		int fil1 = (rand.nextInt(6)+1);
		int fil2=0;
		while(fil1>=fil2) {
			fil2 = (rand.nextInt(7)+2);
		}


		for (int x=0; x <9; x++) {
			for (int y=0; y < 9; y++) {

				if(x<fil1 ) {

					hijo1[x][y]=new Casilla(indiv1.getGenes()[x][y].getNumero(),indiv1.getGenes()[x][y].isFija());

					hijo2[x][y]=new Casilla(indiv2.getGenes()[x][y].getNumero(),indiv2.getGenes()[x][y].isFija());


				}if(x>=fil1&&x<fil2) {
					hijo1[x][y]=new Casilla(indiv2.getGenes()[x][y].getNumero(),indiv2.getGenes()[x][y].isFija());


					hijo2[x][y]=new Casilla(indiv1.getGenes()[x][y].getNumero(),indiv1.getGenes()[x][y].isFija());

				}
				if(x>=fil2) {
					hijo1[x][y]=new Casilla(indiv1.getGenes()[x][y].getNumero(),indiv1.getGenes()[x][y].isFija());


					hijo2[x][y]=new Casilla(indiv2.getGenes()[x][y].getNumero(),indiv2.getGenes()[x][y].isFija());

				}
			}

		}

		newIndiv[0]=new Individual(hijo1);
		newIndiv[0].evaluate();
		newIndiv[1]=new Individual(hijo2);
		newIndiv[1].evaluate();
		return newIndiv;
	}
	/**
	 * Metodo utilizado para cruzar dos individuos=padres y devuelve en un array los dos individuos resultantes=hijos
	 * Este metodo funciona mediante la selecion casillas aleatorias de cada tablero padre para generar dos tableros hijos
	 * @param indiv1
	 * @param indiv2
	 * @return
	 */
	public static Individual[] crossover2Uniforme(Individual indiv1, Individual indiv2) {
		Individual[] newIndiv = new Individual[2];
		Casilla[][] hijo1 = new Casilla[9][9];
		Casilla[][] hijo2 = new Casilla[9][9];
		Random rand = new Random();
		int flip = (rand.nextInt(1));

		for (int x=0; x < 9; x++) {
			for (int y=0; y <9; y++) {
				flip = (rand.nextInt(1));

				if(flip==0) {
					hijo1[x][y]=new Casilla(indiv1.getGenes()[x][y].getNumero(),indiv1.getGenes()[x][y].isFija());


					hijo2[x][y]=new Casilla(indiv2.getGenes()[x][y].getNumero(),indiv2.getGenes()[x][y].isFija());

				}else {
					hijo1[x][y]=new Casilla(indiv2.getGenes()[x][y].getNumero(),indiv2.getGenes()[x][y].isFija());


					hijo2[x][y]=new Casilla(indiv1.getGenes()[x][y].getNumero(),indiv1.getGenes()[x][y].isFija());

				}

			}

		}
		newIndiv[0]=new Individual(hijo1);
		newIndiv[0].evaluate();
		newIndiv[1]=new Individual(hijo2);
		newIndiv[1].evaluate();
		return newIndiv;
	}

}
