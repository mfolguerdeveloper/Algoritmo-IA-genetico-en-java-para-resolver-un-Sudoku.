/**
 * Clase usada para generar las distintas casillas del tablero de un sudoku
 * @author Marcos Folguera Rivera
 *
 */
public class Casilla {

	private int numero;
	private boolean fija;
	
	public Casilla() {
		this.numero=0;
		this.fija=false;
	}

	public Casilla(int numero, boolean fija) {
		
		this.numero = numero;
		this.fija = fija;
	}

	public int getNumero() {
		return numero;
	}

	public void setNumero(int numero) {
		this.numero = numero;
	}

	public boolean isFija() {
		return fija;
	}

	public void setFija(boolean fija) {
		this.fija = fija;
	}
	
	
}
